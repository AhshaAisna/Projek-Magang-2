<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    /**
     * Get all invoices.
     */
    public function index(): JsonResponse
    {
        $invoices = Invoice::with('order')->orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'message' => 'Daftar faktur berhasil diambil',
            'data' => $invoices,
        ]);
    }

    /**
     * Get single invoice by invoice_number or order_id or id.
     */
    public function show(string $id): JsonResponse
    {
        $invoice = Invoice::with('order')
            ->where('invoice_number', $id)
            ->orWhere('order_id', $id)
            ->orWhere('id', $id)
            ->first();

        if (!$invoice) {
            return response()->json([
                'success' => false,
                'message' => "Faktur {$id} tidak ditemukan",
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Detail faktur berhasil diambil',
            'data' => $invoice,
        ]);
    }
}
